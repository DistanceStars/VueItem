<template>
    <div>
        <h1>欢迎来到后台管理系统</h1>
    </div>
</template>

<script>
export default{
    name:'index'
}
</script>