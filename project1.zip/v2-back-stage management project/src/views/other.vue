<template>
其他设置
</template>

<script>


export default{
    name:'APP'
}


</script>